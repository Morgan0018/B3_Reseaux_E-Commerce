/**
 * REngine-based interface to <a href="http://www.rforge.net/Rserve/">Rserve</a>
 */
package org.rosuda.REngine.Rserve ;
