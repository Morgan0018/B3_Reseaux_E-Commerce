package org.rosuda.REngine;

/** S4 REXP is a completely vanilla REXP */
public class REXPS4 extends REXP {
	public REXPS4() { super(); }
	public REXPS4(REXPList attr) { super(attr); }	
}
